﻿import os
from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = "mysecretkey"

USER_FILE = "users.txt"

DEFAULT_USERS = [
    {"username": "admin", "password": "admin123", "role": "admin", "name": "Administrator"},
    {"username": "vishnupriya", "password": "dbms123", "role": "faculty", "name": "Vishnupriya", "subject": "DBMS"},
    {"username": "selvakumar", "password": "os123", "role": "faculty", "name": "Selvakumar", "subject": "Operating System"},
    {"username": "janet", "password": "cn123", "role": "faculty", "name": "Janet", "subject": "Computer Networks"},
    {"username": "bhopche", "password": "java123", "role": "faculty", "name": "Bhopche", "subject": "Java"},
    {"username": "student1", "password": "123", "role": "student", "name": "Alex Smith"}
]

def load_users():
    if not os.path.exists(USER_FILE):
        with open(USER_FILE, "w") as f:
            for u in DEFAULT_USERS:
                subj = u.get("subject", "N/A")
                f.write(f"{u['username']},{u['password']},{u['role']},{u.get('name', u['username'])},{subj}\n")

    users = []
    with open(USER_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                parts = line.split(",")
                if len(parts) >= 3:
                    users.append({
                        "username": parts[0],
                        "password": parts[1],
                        "role": parts[2],
                        "name": parts[3] if len(parts) > 3 else parts[0],
                        "subject": parts[4] if len(parts) > 4 else "N/A"
                    })
    return users

def save_user(username, password, role="student", name="", subject="N/A"):
    with open(USER_FILE, "a") as f:
        f.write(f"\n{username},{password},{role},{name or username},{subject}")

@app.route("/")
def home():
    if "username" in session:
        return redirect(url_for(session["role"]))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        name = request.form.get("name")

        users = load_users()
        if any(u["username"] == username for u in users):
            flash("Username already exists!", "danger")
            return render_template("register.html")

        save_user(username, password, "student", name)
        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        users = load_users()
        for user in users:
            if user["username"] == username and user["password"] == password:
                session["username"] = username
                session["role"] = user["role"]
                session["name"] = user["name"]
                return redirect(url_for(user["role"]))

        flash("Invalid Username or Password", "danger")

    return render_template("login.html")

@app.route("/student")
def student():
    if "username" not in session:
        return redirect(url_for("login"))
    if session["role"] != "student":
        return redirect(url_for("unauthorized"))

    faculty_members = [u for u in load_users() if u["role"] == "faculty"]
    return render_template("student.html", user=session, faculty_list=faculty_members)

@app.route("/faculty")
def faculty():
    if "username" not in session:
        return redirect(url_for("login"))
    if session["role"] != "faculty":
        return redirect(url_for("unauthorized"))

    users = load_users()
    my_data = next((u for u in users if u["username"] == session["username"]), {})
    students = [u for u in users if u["role"] == "student"]
    return render_template("faculty.html", user=session, faculty_info=my_data, students=students)

@app.route("/admin")
def admin():
    if "username" not in session:
        return redirect(url_for("login"))
    if session["role"] != "admin":
        return redirect(url_for("unauthorized"))

    all_users = load_users()
    return render_template("admin.html", user=session, users=all_users)

@app.route("/unauthorized")
def unauthorized():
    return render_template("unauthorized.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
